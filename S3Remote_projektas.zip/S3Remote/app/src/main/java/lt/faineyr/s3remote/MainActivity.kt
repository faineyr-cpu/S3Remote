package lt.faineyr.s3remote

import android.content.Intent
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("s3", MODE_PRIVATE) }
    private var esp: Esp? = null
    private var results: List<Track> = emptyList()
    private var state: EspState? = null
    private var pollJob: Job? = null
    private var resolving = false
    private var userSeeking = false
    private val failed = mutableSetOf<String>()   // ID, kurių nepavyko gauti – nebandyti kas 2 s

    private lateinit var status: TextView
    private lateinit var nowTitle: TextView
    private lateinit var seek: SeekBar
    private lateinit var posText: TextView
    private lateinit var durText: TextView
    private lateinit var resAdapter: TrackAdapter
    private lateinit var queueAdapter: TrackAdapter
    private lateinit var queueHeader: TextView
    private lateinit var resHeader: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        nowTitle = findViewById(R.id.nowTitle)
        seek = findViewById(R.id.seek)
        posText = findViewById(R.id.posText)
        durText = findViewById(R.id.durText)
        queueHeader = findViewById(R.id.queueHeader)
        resHeader = findViewById(R.id.resHeader)

        // Rezultatai: paspaudus – groti dabar, "+" – į eilės galą
        resAdapter = TrackAdapter("+",
            onClick = { t -> addTracks(listOf(t), play = true) },
            onAction = { t -> addTracks(listOf(t), play = false) })
        // Eilė: paspaudus – groti šią, "✕" – pašalinti
        queueAdapter = TrackAdapter("✕",
            onClick = { t -> espCmd("play", t.id) },
            onAction = { t -> espCmd("del", t.id) })
        findViewById<RecyclerView>(R.id.results).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = resAdapter
        }
        findViewById<RecyclerView>(R.id.queue).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = queueAdapter
        }

        val query = findViewById<EditText>(R.id.query)
        findViewById<Button>(R.id.btnSearch).setOnClickListener { search(query.text.toString()) }
        query.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { search(query.text.toString()); true } else false
        }
        findViewById<Button>(R.id.btnPlayAll).setOnClickListener {
            if (results.isNotEmpty()) addTracks(results, play = true, replace = true)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { espCmd("stop") }
        findViewById<Button>(R.id.btnNext).setOnClickListener { espCmd("next") }
        findViewById<Button>(R.id.btnVolUp).setOnClickListener {
            espCmd("vol", ((state?.vol ?: 10) + 1).coerceAtMost(21).toString())
        }
        findViewById<Button>(R.id.btnVolDown).setOnClickListener {
            espCmd("vol", ((state?.vol ?: 10) - 1).coerceAtLeast(0).toString())
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this).setMessage("Išvalyti eilę?")
                .setPositiveButton("Taip") { _, _ -> espCmd("clear") }
                .setNegativeButton("Ne", null).show()
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { settingsDialog() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) posText.text = fmt(p.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar) { userSeeking = true }
            override fun onStopTrackingTouch(s: SeekBar) {
                userSeeking = false; espCmd("seek", s.progress.toString())
            }
        })

        connect()
        if (esp == null) settingsDialog()
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); handleShare(intent)
    }

    /** "Bendrinti" iš YouTube -> pridėti į eilę */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        i.action = null
        lifecycleScope.launch {
            try {
                val tracks = withContext(Dispatchers.IO) { Yt.search(text) }
                if (tracks.isEmpty()) toast("Nuorodoje nerasta kūrinių")
                else addTracks(tracks, play = state?.playing != true)
            } catch (e: Exception) { toast("Klaida: ${e.message}") }
        }
    }

    override fun onResume() {
        super.onResume()
        pollJob = lifecycleScope.launch {
            while (isActive) { refresh(); delay(2000) }
        }
    }

    override fun onPause() { super.onPause(); pollJob?.cancel() }

    private fun connect() {
        val host = prefs.getString("host", "") ?: ""
        esp = if (host.isBlank()) null else Esp(host, prefs.getString("key", "") ?: "")
    }

    // ---------- ESP būsena ir nuorodų atnaujinimas ----------
    private suspend fun refresh() {
        val e = esp ?: run { status.text = "Nenurodytas ESP adresas (⚙)"; return }
        try {
            val s = withContext(Dispatchers.IO) { e.state() }
            state = s
            status.text = "ESP prisijungęs · garsas ${s.vol}" +
                (if (s.need.isNotEmpty()) " · atnaujinama nuorodų: ${s.need.size}" else "")
            nowTitle.text = s.title.ifBlank { "—" }
            if (!userSeeking) {
                seek.max = s.dur.toInt().coerceAtLeast(1)
                seek.progress = s.pos.toInt()
                seek.isEnabled = s.dur > 0
                posText.text = fmt(s.pos); durText.text = fmt(s.dur)
            }
            queueHeader.text = "Eilė (${s.queue.size})"
            queueAdapter.submit(s.queue, s.id)
            refreshUrls(e, s.need)
        } catch (ex: Exception) {
            status.text = "ESP nepasiekiamas: ${ex.message}"
        }
    }

    /** ESP praneša, kurių kūrinių nuorodos pasibaigė/nėra – gauname naujas (po 5). */
    private fun refreshUrls(e: Esp, need: List<String>) {
        val todo = need.filter { it !in failed }.take(5)
        if (resolving || todo.isEmpty()) return
        resolving = true
        lifecycleScope.launch {
            try {
                val got = withContext(Dispatchers.IO) {
                    todo.mapNotNull { id ->
                        val t = Track(id, "", 0)
                        try { if (Yt.resolve(t)) t else { failed += id; null } }
                        catch (_: Exception) { failed += id; null }
                    }.also { e.urls(it) }
                }
                if (got.size < todo.size) toast("Kai kurių kūrinių gauti nepavyko (gal privatūs)")
            } catch (ex: Exception) {
                toast("Nuorodų atnaujinimo klaida: ${ex.message}")
            } finally { resolving = false }
        }
    }

    // ---------- Paieška ir pridėjimas ----------
    private fun search(q: String) {
        if (q.isBlank()) return
        resHeader.text = "Ieškoma..."
        lifecycleScope.launch {
            try {
                results = withContext(Dispatchers.IO) { Yt.search(q.trim()) }
                resHeader.text = "Rezultatai (${results.size})"
                resAdapter.submit(results, null)
            } catch (e: Exception) {
                resHeader.text = "Rezultatai"
                toast("Paieškos klaida: ${e.message}")
            }
        }
    }

    /** Pirmo kūrinio nuorodą gauname iš karto (kad grotų greitai), kitas – ESP paprašys pats. */
    private fun addTracks(tracks: List<Track>, play: Boolean, replace: Boolean = false) {
        val e = esp ?: return toast("Nustatyk ESP adresą (⚙)")
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val list = tracks.map { it.copy() }
                    list.take(if (play) 1 else 0).forEach { runCatching { Yt.resolve(it) } }
                    if (replace) e.cmd("clear")
                    e.add(list, play)
                }
                toast(if (play) "Grojama" else "Pridėta į eilę: ${tracks.size}")
                refresh()
            } catch (ex: Exception) { toast("Klaida: ${ex.message}") }
        }
    }

    private fun espCmd(c: String, v: String = "") {
        val e = esp ?: return toast("Nustatyk ESP adresą (⚙)")
        lifecycleScope.launch {
            try { withContext(Dispatchers.IO) { e.cmd(c, v) }; refresh() }
            catch (ex: Exception) { toast("Klaida: ${ex.message}") }
        }
    }

    // ---------- Nustatymai + automatinė ESP paieška tinkle (mDNS) ----------
    private fun settingsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val host = EditText(this).apply {
            hint = "ESP adresas, pvz. 192.168.0.35"; setText(prefs.getString("host", ""))
        }
        val key = EditText(this).apply {
            hint = "API raktas"; setText(prefs.getString("key", ""))
        }
        val find = Button(this).apply { text = "Rasti ESP tinkle" }
        box.addView(host); box.addView(key); box.addView(find)
        find.setOnClickListener {
            find.text = "Ieškoma..."
            discover { ip ->
                runOnUiThread {
                    if (ip != null) { host.setText(ip); find.text = "Rasta: $ip" }
                    else find.text = "Nerasta – įvesk IP ranka"
                }
            }
        }
        AlertDialog.Builder(this).setTitle("ESP nustatymai").setView(box)
            .setPositiveButton("Išsaugoti") { _, _ ->
                prefs.edit().putString("host", host.text.toString().trim())
                    .putString("key", key.text.toString().trim()).apply()
                failed.clear(); connect()
            }
            .setNegativeButton("Atšaukti", null).show()
    }

    /** ESP skelbia paslaugą "_s3player._tcp" (MDNS.addService). */
    private fun discover(done: (String?) -> Unit) {
        val nsd = getSystemService(NSD_SERVICE) as NsdManager
        var finished = false
        val listener = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(si: NsdServiceInfo) {
                @Suppress("DEPRECATION")
                nsd.resolveService(si, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        if (!finished) { finished = true; done(r.host?.hostAddress) }
                    }
                    override fun onResolveFailed(s: NsdServiceInfo, err: Int) {}
                })
            }
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(si: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(t: String, err: Int) {
                if (!finished) { finished = true; done(null) }
            }
            override fun onStopDiscoveryFailed(t: String, err: Int) {}
        }
        nsd.discoverServices("_s3player._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
        lifecycleScope.launch {
            delay(8000)
            runCatching { nsd.stopServiceDiscovery(listener) }
            if (!finished) { finished = true; done(null) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        fun fmt(s: Long) = if (s <= 0) "0:00" else "%d:%02d".format(s / 60, s % 60)
    }
}

/** Bendras sąrašo adapteris rezultatams ir eilei. */
class TrackAdapter(
    private val actionText: String,
    private val onClick: (Track) -> Unit,
    private val onAction: (Track) -> Unit
) : RecyclerView.Adapter<TrackAdapter.VH>() {
    private var items: List<Track> = emptyList()
    private var currentId: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val info: TextView = v.findViewById(R.id.info)
        val action: Button = v.findViewById(R.id.action)
    }

    fun submit(list: List<Track>, current: String?) {
        if (list == items && current == currentId) return
        items = list; currentId = current; notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.row, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val t = items[i]
        h.title.text = (if (t.id == currentId) "▶ " else "") + t.title.ifBlank { t.id }
        h.info.text = MainActivity.fmt(t.dur)
        h.action.text = actionText
        h.itemView.setOnClickListener { onClick(t) }
        h.action.setOnClickListener { onAction(t) }
    }
}
